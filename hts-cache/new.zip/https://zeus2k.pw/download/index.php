<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=no" />
	<base href=https://zeus2k.pw/download/">
	
	<title>FileUpload</title>
	
	<!-- Load Bootstrap -->
	<link rel="stylesheet" href="media/bootstrap/css/bootstrap.min.css" />
	
	<!-- Load Custom Style -->
	<link rel="stylesheet" href="media/css/style.css" />
	<link rel="stylesheet" href="media/css/style-blue.css" />
	
	<!-- Google Fonts -->
	<link href='http://fonts.googleapis.com/css?family=Montserrat:400,700|Roboto:400,300,100' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300' rel='stylesheet' type='text/css'>
	
	<!-- FontAwesome Icons -->
	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
	
	<!-- HTML5 Shiv and Respond.js for IE8 -just in case- -->
	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
</head><body>
	<!-- Navigation Bar -->
	<nav class="navbar navbar-static-top">
		<!-- Container -->
		<div class="container">
			<div class="navbar-header">
				<!-- Toggle Button first -->
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navigation">
					<!-- For Screen Readers -->
					<span class="sr-only">Toggle Navigation</span>
					
					<!-- Icon bars -->
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				
				<a class="navbar-brand" href="https://zeus2k.pw/download/"><img src="media/img/filex@3x.png" height="170%" /></a>
			</div>
			
			<!-- Navigation Links -->
			<div class="collapse navbar-collapse" id="navigation">
				<ul class="nav navbar-nav navbar-right">
					<li class="active"><a href="https://zeus2k.pw/download/index.php">HOME</a></li><li><a href="https://zeus2k.pw/download/check-stats/">CHECK STATS</a></li>				</ul>
			</div>
		</div>
	</nav><!-- End of navigation -->	
	<!-- First Container -->
	<section class="container first-container">
		<div class="row">
			<label for="fileinput" class="over-container"></label>
			<div class="col-xs-4 left-icon"> 
				<i class="fa fa-cloud-upload"></i>
			</div>
			<div class="col-xs-8 right-text">
				<p>Click or drop here to upload a new file</p>
			</div>
		</div>
		
		<input type="file" name="fileinput" class="hide" id="fileinput" />
	</section>
	
	<!-- Second Container -->
	<section class="container-fluid second-container">
		<div class="container">
			<form method="post" action="index.php" name="upload">
				<div class="row">
					<div class="col-xs-4 column">
						<div class="head text-center">
							<p class="form-inline">Delete files after <input type="text" name="days" class="form-control" style="width:40px;" /> days</p>
						</div>
					</div>
					
					<div class="col-xs-4 column">
						<div class="head text-center">
							<p style="font:Rubik;"class="form-inline">Delete files after <input type="text" name="downloads" class="form-control" style="width:40px;" /> downloads</p>
						</div>
					</div>
					
					<div class="col-xs-4 column">
						<div class="head text-center">
							<p>Protect files with the following password:</p>
							<input type="text" name="password" class="form-control big" />
						</div>
					</div>
				</div>
				
				<button type="submit" class="btn btn-success pull-right upload">UPLOAD</button>
			</form>
		</div>
	</section>
	
	<!-- Third Container / Information -->
	<section class="container-fluid information">
		<div class="container">
			<div class="row">
				<div class="col-xs-4 column text-center">
					23 Uploaded Files
				</div>
				<div class="col-xs-4 column text-center">
					555 Downloads
				</div>
				<div class="col-xs-4 column text-center">
					3 Expired Files
				</div>
			</div>
		</div>
	</section>
	
	
	<!-- Footer -->
	<footer class="container-fluid text-center">
		<p>FileUpload - All rights reserved</p>	</footer>
	
	
	<!-- Placed at the end of the document so the pages load faster -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
	<script src="media/bootstrap/js/bootstrap.min.js"></script>
	<script>
		var all_extensions_allowed = true;
		var allowed_extensions = [''];	
	</script>
	<script src="media/js/filex.init.js"></script>
</body>
</html>